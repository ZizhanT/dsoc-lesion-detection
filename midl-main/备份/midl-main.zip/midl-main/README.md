# midl

医学图像深度学习项目

# 附录 环境安装和配置
```bash
git clone git@gitcode.com:yant7589/midl.git
cd midl
# 拷贝权重文件：anns/resnet_best_model.pth    anns/yolov11/weights/yolov11_best.pt
# 拷贝视频文件目录及文件 apps/xjd/demo/videos/
# 拷贝工作目录 apps/xjd/demo/work/
```